// ================= SISTEMA DE COLORIR =================
const nomesCores = {
    '#000000': 'Preto',
    '#ffffff': 'Branco',
    '#ff0000': 'Vermelho',
    '#ff9800': 'Laranja',
    '#ffeb3b': 'Amarelo',
    '#4caf50': 'Verde',
    '#2196f3': 'Azul',
    '#9c27b0': 'Roxo',
    '#e91e63': 'Rosa',
    '#795548': 'Marrom'
};

let corSelecionada = '#000000';

// Selecionar cor
document.querySelectorAll('.cor-btn').forEach(botao => {
    botao.addEventListener('click', function () {
        document.querySelectorAll('.cor-btn').forEach(b => b.classList.remove('ativa'));
        this.classList.add('ativa');
        corSelecionada = this.dataset.cor;
        document.getElementById('nomeCorAtual').textContent = nomesCores[corSelecionada];
    });
});

document.querySelector('.cor-btn[data-cor="#000000"]').classList.add('ativa');

// Colorir ao clicar no SVG
document.querySelectorAll('.desenho svg').forEach(svg => {
    svg.addEventListener('click', function (e) {
        e.stopPropagation();
        if (e.target.tagName === 'svg') return;
        e.target.style.fill = corSelecionada;
        e.target.setAttribute('data-pintado', 'true');
        const celula = svg.closest('.celula-objeto');
        if (celula) celula.classList.add('colorida');
    });

    // Click na célula (pinta tudo)
    const celula = svg.closest('.celula-objeto');
    if (celula) {
        celula.addEventListener('click', function (e) {
            if (e.target.closest('.desenho')) return;
            svg.querySelectorAll('path, circle, ellipse, rect, line').forEach(el => {
                el.style.fill = corSelecionada;
                el.setAttribute('data-pintado', 'true');
            });
            celula.classList.add('colorida');
        });
    }
});

// Limpar cores
document.getElementById('limparCores').addEventListener('click', function () {
    if (confirm('Deseja apagar todas as cores pintadas?')) {
        document.querySelectorAll('.desenho svg *').forEach(el => {
            el.style.fill = '';
            el.removeAttribute('data-pintado');
        });
        document.querySelectorAll('.celula-objeto').forEach(c => c.classList.remove('colorida'));
    }
});

// Modo impressão
document.getElementById('modoImprimir').addEventListener('click', function () {
    if (confirm('Ativar modo impressão? As cores pintadas serão mantidas, mas a paleta ficará oculta.')) {
        document.body.classList.add('modo-impressao');
        setTimeout(() => window.print(), 300);
    }
});

window.addEventListener('afterprint', function () {
    document.body.classList.remove('modo-impressao');
});

// ================= SISTEMA DE QUESTÕES =================
const respostasCorretas = {
    'A2': 'bola', 'A3': 'xicara', 'A4': 'peixe',
    'B1': 'maca', 'B2': 'abelha', 'B3': 'bolo',
    'B4': 'flor', 'C1': 'formiga'
};

const respostasUsuario = {};

document.querySelectorAll('.circulo-resposta').forEach(opcao => {
    opcao.addEventListener('click', function (e) {
        e.stopPropagation();
        const posicao = this.dataset.posicao;
        document.querySelectorAll(`.circulo-resposta[data-posicao="${posicao}"]`).forEach(item => {
            item.classList.remove('circulado');
        });
        this.classList.add('circulado');
        respostasUsuario[posicao] = this.dataset.resposta;
    });
});

// Verificar
document.getElementById('verificarRespostas').addEventListener('click', function () {
    let acertos = 0;
    const total = Object.keys(respostasCorretas).length;
    const resultado = document.getElementById('resultadoAtividade');
    const gabarito = document.getElementById('gabaritoSection');

    if (Object.keys(respostasUsuario).length < total) {
        resultado.className = 'resultado-atividade continue visivel';
        resultado.innerHTML = `⚠️ Responda todas as ${total} questões antes de verificar!`;
        return;
    }

    for (let posicao in respostasCorretas) {
        if (respostasUsuario[posicao] === respostasCorretas[posicao]) acertos++;
    }

    const percentual = Math.round((acertos / total) * 100);

    if (acertos === total) {
        resultado.className = 'resultado-atividade excelente visivel';
        resultado.innerHTML = `🎉 Parabéns! Você acertou TODAS as ${total} questões! (${percentual}%)`;
    } else if (acertos >= total * 0.7) {
        resultado.className = 'resultado-atividade bom visivel';
        resultado.innerHTML = `👏 Muito bem! Você acertou ${acertos}/${total} (${percentual}%). Continue praticando!`;
    } else {
        resultado.className = 'resultado-atividade continue visivel';
        resultado.innerHTML = `📚 Você acertou ${acertos}/${total} (${percentual}%). Não desanime, estude mais!`;
    }

    gabarito.style.display = 'block';
    resultado.scrollIntoView({ behavior: 'smooth', block: 'center' });
});

// Limpar respostas
document.getElementById('limparRespostas').addEventListener('click', function () {
    document.querySelectorAll('.circulo-resposta').forEach(opcao => opcao.classList.remove('circulado'));
    for (let key in respostasUsuario) delete respostasUsuario[key];
    document.getElementById('resultadoAtividade').classList.remove('visivel');
    document.getElementById('gabaritoSection').style.display = 'none';
    window.scrollTo({ top: 0, behavior: 'smooth' });
});

// Imprimir
document.getElementById('imprimirAtividade').addEventListener('click', function () {
    document.body.classList.add('modo-impressao');
    setTimeout(() => window.print(), 300);
});

// Destacar posição no hover
document.querySelectorAll('.celula-objeto').forEach(celula => {
    celula.addEventListener('mouseenter', function () {
        const posicao = this.dataset.posicao;
        document.querySelectorAll('.posicao-questao').forEach(pq => {
            if (pq.textContent.trim() === posicao) {
                pq.style.transform = 'scale(1.1)';
                pq.style.background = '#4a148c';
            }
        });
    });

    celula.addEventListener('mouseleave', function () {
        document.querySelectorAll('.posicao-questao').forEach(pq => {
            pq.style.transform = 'scale(1)';
            pq.style.background = '#000';
        });
    });
});
